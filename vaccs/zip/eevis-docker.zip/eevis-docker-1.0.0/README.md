# eevis-docker

Run [eevis-go](https://github.com/vaccs/eevis-go) locally in a single Linux
Docker container: MySQL, the compiled Go app, and (optionally) nginx all run
inside that one container. The source code is never copied from your local
checkout - each container start does a fresh `git clone`/`git fetch` of the
real repo, then compiles it with `go build`, so you're always running exactly
what's committed.

## Quick start

```bash
cd eevis-docker
scripts/run.sh          # "local" mode: app served directly
scripts/run.sh web      # "web" mode: nginx reverse-proxies to the app
```

`run.sh`:
1. Checks that Docker + Compose v2 are installed and the daemon is running -
   installs/starts them if not (asks before making any system change).
2. Picks a host port, starting at 8080 and moving up if it's already taken.
3. Runs `docker compose up --build`.
4. Waits for `/eevis/health` to respond.
5. Opens your default browser to the app.

Stop it with:

```bash
scripts/stop.sh              # stop, keep the database
scripts/stop.sh --wipe-db    # stop and delete the MySQL volume
```

## The two modes

These mirror the two production configurations already documented in
eevis-go's `CONFIGURATION.md`:

- **local** - the compiled app binds `0.0.0.0:8080` inside the container and
  is exposed directly to the host. Equivalent to the "Direct" config.
- **web** - the app binds `127.0.0.1:8081` (loopback only) and nginx listens
  on `0.0.0.0:8080`, reverse-proxying to it. Equivalent to the "Behind Reverse
  Proxy" config, using nginx as the web server in front of the app.

In both modes the container's internal port is always 8080; only the *host*
port that maps to it changes if 8080 is busy.

## Configuration

Copy `.env.example` to `.env` to override defaults (DB credentials, session
secret, seeded admin account, which branch to clone). `run.sh` creates `.env`
for you on first run if it doesn't exist.

A default admin user (`admin` / `admin123` unless overridden in `.env`) is
seeded the first time the `users` table is empty.

## Cloning the repo

`eevis-go` is public, so the default `REPO_URL` (an HTTPS URL) clones with no
authentication at all - nothing is copied into the image, the container just
does a normal anonymous `git clone`/`git fetch`.

If it's ever made private, `run.sh` also detects a running host ssh-agent
with loaded keys (`ssh-add -l`) and forwards it into the container (via
Docker Desktop's `/run/host-services/ssh-auth.sock` on macOS, or your real
`$SSH_AUTH_SOCK` on Linux) so `git clone`/`git fetch` can authenticate with
your existing keys - just set `REPO_URL` in `.env` back to the SSH form
(`git@github.com:vaccs/eevis-go.git`).

Or use an HTTPS token instead:

```
REPO_URL=https://x-access-token:<GITHUB_TOKEN>@github.com/vaccs/eevis-go.git
```

## What's in the container

- MySQL server (data persisted in the `mysql-data` Docker volume across
  restarts; schema applied from the repo's `schema.sql`)
- Go toolchain, used to `go build` the app on every start
- nginx (used only in `web` mode)
- git + openssh-client, used to clone/update the source

See `Dockerfile` and `entrypoint.sh` for the exact startup sequence.

## Files

| File | Purpose |
|---|---|
| `Dockerfile` | Base image: Go, MySQL, nginx, git, tini |
| `entrypoint.sh` | Init MySQL, clone+build the app, start daemons, exec the app |
| `nginx/eevis.conf.template` | Reverse proxy config used in `web` mode |
| `docker-compose.yml` | Single-service compose file |
| `docker-compose.ssh-agent.yml` | Overlay adding ssh-agent forwarding |
| `scripts/install-prereqs.sh` | Installs/starts Docker if missing |
| `scripts/run.sh` | Main entry point (see Quick start) |
| `scripts/stop.sh` | Tears the container down |
| `scripts/lib.sh` | Shared shell helpers |

#!/bin/bash
# Makes sure Docker (+ Compose v2) is installed and the daemon is running.
# Asks before making any system-wide change (installing Homebrew/Docker
# Desktop, running get.docker.com, adding you to the docker group, etc).
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# shellcheck source=./lib.sh
source ./lib.sh

OS="$(detect_os)"

install_docker_darwin() {
    if ! have_cmd brew; then
        echo "Homebrew is required to install Docker Desktop automatically."
        if confirm "Install Homebrew now?"; then
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        else
            echo "Please install Docker Desktop manually: https://www.docker.com/products/docker-desktop/"
            exit 1
        fi
    fi

    if ! have_cmd docker; then
        if confirm "Docker is not installed. Install Docker Desktop via Homebrew now?"; then
            brew install --cask docker
        else
            echo "Please install Docker Desktop manually: https://www.docker.com/products/docker-desktop/"
            exit 1
        fi
    fi

    if ! docker info >/dev/null 2>&1; then
        echo "Starting Docker Desktop..."
        open -a Docker
        echo -n "Waiting for the Docker daemon to come up"
        for _ in $(seq 1 60); do
            docker info >/dev/null 2>&1 && { echo; return 0; }
            echo -n "."
            sleep 2
        done
        echo
        echo "Docker Desktop hasn't finished starting yet."
        echo "It may need one-time manual setup (privileged helper install / license)."
        echo "Open the Docker Desktop app, complete any prompts, then re-run this script."
        exit 1
    fi
}

install_docker_linux() {
    if ! have_cmd docker; then
        if confirm "Docker is not installed. Install it now via get.docker.com (requires sudo)?"; then
            curl -fsSL https://get.docker.com | sudo sh
        else
            echo "Please install Docker manually: https://docs.docker.com/engine/install/"
            exit 1
        fi
    fi

    # On WSL2, `docker` is very often just a client shim from Docker Desktop's
    # WSL integration (Settings > Resources > WSL Integration) - there's no
    # local dockerd, systemd unit, or docker group to manage in that case.
    # Only touch systemd/usermod when a real local install is present, so we
    # don't blindly run them against things that don't exist.
    local has_local_unit=0
    if have_cmd systemctl && systemctl list-unit-files docker.service >/dev/null 2>&1; then
        has_local_unit=1
        sudo systemctl enable --now docker || true
    fi

    if ! docker compose version >/dev/null 2>&1 && ! have_cmd docker-compose; then
        if confirm "Docker Compose plugin not found. Install docker-compose-plugin now?"; then
            if have_cmd apt-get; then
                sudo apt-get update && sudo apt-get install -y docker-compose-plugin
            elif have_cmd dnf; then
                sudo dnf install -y docker-compose-plugin
            else
                echo "Please install the Docker Compose plugin manually for your distro."
                exit 1
            fi
        fi
    fi

    if ! docker info >/dev/null 2>&1; then
        if [ "$has_local_unit" -eq 0 ] && is_wsl; then
            echo "The docker CLI is present but the daemon isn't reachable, and there's no"
            echo "local docker.service on this WSL distro - Docker looks like it's meant to"
            echo "come from Docker Desktop's WSL integration rather than a local install."
            echo "On Windows: open Docker Desktop, make sure it's running, then check"
            echo "Settings > Resources > WSL Integration and enable it for this distro."
            exit 1
        fi

        if groups "$USER" | grep -qw docker; then
            echo "The docker daemon isn't reachable yet. Try again in a new shell (group membership needs a re-login)."
        elif getent group docker >/dev/null 2>&1; then
            if confirm "Add $USER to the docker group so you don't need sudo for docker commands?"; then
                sudo usermod -aG docker "$USER"
                echo "Added. Log out and back in (or run 'newgrp docker'), then re-run this script."
            fi
        else
            echo "No local 'docker' group exists and the daemon isn't reachable."
            echo "Please install Docker Engine manually: https://docs.docker.com/engine/install/"
        fi
        exit 1
    fi
}

install_docker_windows() {
    if ! have_cmd docker || ! docker info >/dev/null 2>&1; then
        echo "Docker Desktop isn't installed or isn't running."
        echo "Install/start it manually: https://www.docker.com/products/docker-desktop/"
        echo "(There's no unattended installer for Windows the way there is for macOS/Linux.)"
        exit 1
    fi
}

case "$OS" in
    darwin)   install_docker_darwin ;;
    linux)    install_docker_linux ;;
    windows)  install_docker_windows ;;
    *)
        echo "Unsupported OS for auto-install: $(uname -s)"
        echo "Please install Docker + Compose v2 manually: https://docs.docker.com/get-docker/"
        exit 1
        ;;
esac

if ! docker compose version >/dev/null 2>&1; then
    echo "ERROR: 'docker compose' (v2) is required but not available." >&2
    exit 1
fi

echo "Docker is installed and running."

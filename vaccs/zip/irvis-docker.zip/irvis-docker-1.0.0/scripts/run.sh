#!/bin/bash
# Launch irvis-go locally in Docker.
#
# Usage: scripts/run.sh [local|web] [--no-browser]
#   local  (default) - app is reachable directly on the host port
#   web            - nginx fronts the app, as in a real deployment
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
source ./scripts/lib.sh

MODE="local"
OPEN_BROWSER=1
for arg in "$@"; do
    case "$arg" in
        local|web) MODE="$arg" ;;
        --no-browser) OPEN_BROWSER=0 ;;
        -h|--help)
            echo "Usage: $0 [local|web] [--no-browser]"
            exit 0
            ;;
        *)
            echo "Unknown argument: $arg" >&2
            exit 1
            ;;
    esac
done

echo "== Checking Docker installation =="
./scripts/install-prereqs.sh

if [ ! -f .env ]; then
    echo "No .env found, creating one from .env.example"
    cp .env.example .env
fi
set -a
# shellcheck disable=SC1091
source ./.env
set +a

export MODE
HOST_PORT="$(find_free_port 8080)"
export HOST_PORT
if [ "$HOST_PORT" != "8080" ]; then
    echo "Port 8080 is in use, using $HOST_PORT instead."
fi

COMPOSE_FILES=(-f docker-compose.yml)
SSH_SOCK="$(find_ssh_agent_sock || true)"
if [ -n "$SSH_SOCK" ]; then
    echo "Forwarding host SSH agent for git clone (found loaded key(s))."
    export SSH_AUTH_SOCK_HOST="$SSH_SOCK"
    COMPOSE_FILES+=(-f docker-compose.ssh-agent.yml)
else
    echo "No usable ssh-agent found on the host."
    echo "Cloning ${REPO_URL:-the repo} inside the container will only work if it's"
    echo "reachable without your keys (e.g. a public HTTPS URL, or REPO_URL in .env"
    echo "rewritten to an HTTPS token form). See README.md for details."
fi

echo "== Mode: $MODE | Host port: $HOST_PORT =="
docker compose "${COMPOSE_FILES[@]}" up -d --build

echo "== Waiting for irvis to become healthy =="
HEALTH_URL="http://127.0.0.1:${HOST_PORT}/healthz"
READY=0
for _ in $(seq 1 120); do
    if curl -fs "$HEALTH_URL" >/dev/null 2>&1; then
        READY=1
        break
    fi
    sleep 2
done

if [ "$READY" -ne 1 ]; then
    echo "irvis did not become healthy in time. Recent logs:"
    docker compose logs --tail=100 irvis
    exit 1
fi

APP_URL="http://127.0.0.1:${HOST_PORT}/irvis"
echo ""
echo "irvis is up: $APP_URL"
echo "Default admin login (first run only): ${SEED_ADMIN_USER:-admin} / ${SEED_ADMIN_PASSWORD:-admin123}"
echo "Logs:   docker compose logs -f irvis"
echo "Stop:   scripts/stop.sh"
echo ""

if [ "$OPEN_BROWSER" -eq 1 ]; then
    open_browser "$APP_URL"
fi

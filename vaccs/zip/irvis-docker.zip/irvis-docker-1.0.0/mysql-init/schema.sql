-- IRVIS database schema, applied by entrypoint.sh on every container start.
--
-- This is tracked here in irvis-docker rather than pulled from the cloned
-- irvis-go repo: irvis-go's own committed SQL files (create_irvis_db.sql) are
-- stale and are missing the is_admin column that cmd/server/main.go actually
-- queries. This file matches the real, current schema.

CREATE DATABASE IF NOT EXISTS irvis CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE irvis;

CREATE TABLE IF NOT EXISTS users (
    id              INT NOT NULL AUTO_INCREMENT,
    username        VARCHAR(64) NOT NULL,
    email           VARCHAR(255) NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    is_logged_in    TINYINT(1) NOT NULL DEFAULT 0,
    is_admin        TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_username (username),
    UNIQUE KEY uniq_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

# irvis-docker

Run [irvis-go](https://github.com/vaccs/irvis-go) locally in a single Linux
Docker container: MySQL, the compiled Go app, and (optionally) nginx all run
inside that one container. The source code is never copied from your local
checkout - each container start does a fresh `git clone`/`git fetch` of the
real repo, then compiles it with `go build`, so you're always running exactly what's committed.

## Quick start

```bash
git clone https://github.com/vaccs/irvis-docker.git
cd irvis-docker
scripts/run.sh          # "local" mode: app served directly
scripts/run.sh web      # "web" mode: nginx reverse-proxies to the app
```

`run.sh`:
1. Checks that Docker + Compose v2 are installed and the daemon is running -
   installs/starts them if not (asks before making any system change).
2. Picks a host port, starting at 8080 and moving up if it's already taken.
3. Runs `docker compose up -d --build`.
4. Waits for `/healthz` to respond, using `curl` on the host - this needs to
   already be on your `PATH` (it ships with macOS, most Linux distros, and
   Git Bash for Windows); `install-prereqs.sh` doesn't install it. Without it
   this step always times out and dumps the container logs, even if the app
   actually came up fine.
5. Opens your default browser to the app.

Stop it with:

```bash
scripts/stop.sh              # stop, keep the database
scripts/stop.sh --wipe-db    # stop and delete the MySQL volume
```

## The two modes

- **local** - the compiled app binds `0.0.0.0:8080` inside the container and
  is exposed directly to the host.
- **web** - the app binds `8081` (not published to the host) and nginx
  listens on `0.0.0.0:8080`, reverse-proxying to it - closer to a real
  deployment fronted by a web server.

In both modes the container's internal port is always 8080; only the *host*
port that maps to it changes if 8080 is busy.

## Configuration

Copy `.env.example` to `.env` to override defaults (DB credentials, GitHub
token, seeded admin account, which branch to clone). `run.sh` creates `.env`
for you on first run if it doesn't exist.

A default admin user (`admin` / `admin123` unless overridden in `.env`) is
seeded the first time the `users` table is empty.

## Windows

Two ways to run this from Windows:

- **Git Bash** - run `scripts/run.sh` there (not the `.cmd`/PowerShell
  prompt), with Docker Desktop installed and running - `install-prereqs.sh`
  won't auto-install Docker on Windows the way it does on macOS/Linux, so do
  that manually first. ssh-agent forwarding isn't wired up here, so a private
  `irvis-go` repo needs the HTTPS token form of `REPO_URL` (see below)
  instead.
- **WSL2** - `uname` reports plain Linux inside WSL, so `install-prereqs.sh`
  takes the Linux path, but it detects when `docker` is just a client shim
  from Docker Desktop's WSL integration (no local `docker.service` or
  `docker` group in that case) and skips `systemctl`/`usermod` accordingly. If
  the daemon isn't reachable, open Docker Desktop on Windows and enable this
  distro under Settings > Resources > WSL Integration, then re-run
  `scripts/run.sh`. The default browser is opened via `explorer.exe`.

## Cloning the repo

`irvis-go` is public, so the default `REPO_URL` (an HTTPS URL) clones with no
authentication at all - nothing is copied into the image, the container just
does a normal anonymous `git clone`/`git fetch`.

If it's ever made private, `run.sh` also detects a running host ssh-agent
with loaded keys (`ssh-add -l`) and forwards it into the container (via
Docker Desktop's `/run/host-services/ssh-auth.sock` on macOS, or your real
`$SSH_AUTH_SOCK` on Linux) so `git clone`/`git fetch` can authenticate with
your existing keys - just set `REPO_URL` in `.env` back to the SSH form
(`git@github.com:vaccs/irvis-go.git`).

Or use an HTTPS token instead:

```
REPO_URL=https://x-access-token:<GITHUB_TOKEN>@github.com/vaccs/irvis-go.git
```

## Database schema

The schema applied on every start comes from `mysql-init/schema.sql` in this
repo, not from the cloned irvis-go source: irvis-go's own committed SQL files
are stale (missing the `is_admin` column that the app actually queries), so
the up-to-date schema is tracked here instead.

## What's in the container

- MySQL server (data persisted in the `mysql-data` Docker volume across
  restarts; schema applied from this repo's `mysql-init/schema.sql`)
- Go toolchain, used to `go build` the app on every start
- nginx (used only in `web` mode)
- git + openssh-client, used to clone/update the source

See `Dockerfile` and `entrypoint.sh` for the exact startup sequence.

## Files

| File | Purpose |
|---|---|
| `Dockerfile` | Base image: Go, MySQL, nginx, git, tini |
| `entrypoint.sh` | Init MySQL, clone+build the app, start daemons, exec the app |
| `mysql-init/schema.sql` | Authoritative DB schema, applied on every start |
| `nginx/irvis.conf.template` | Reverse proxy config used in `web` mode |
| `docker-compose.yml` | Single-service compose file |
| `docker-compose.ssh-agent.yml` | Overlay adding ssh-agent forwarding |
| `scripts/install-prereqs.sh` | Installs/starts Docker if missing |
| `scripts/run.sh` | Main entry point (see Quick start) |
| `scripts/stop.sh` | Tears the container down |
| `scripts/lib.sh` | Shared shell helpers |

#!/bin/bash
set -euo pipefail

MODE="${MODE:-local}"                       # local | web
CONTAINER_PORT=8080                         # fixed internal port (see Dockerfile EXPOSE);
                                             # the host port it's mapped to is chosen by scripts/run.sh
APP_INTERNAL_PORT="${APP_INTERNAL_PORT:-8081}"  # app port behind nginx, web mode only

REPO_URL="${REPO_URL:-https://github.com/vaccs/irvis-go.git}"
REPO_REF="${REPO_REF:-main}"
SRC_DIR="/opt/irvis-src"
SCHEMA_FILE="/opt/irvis-docker/schema.sql"

DB_NAME="${DB_NAME:-irvis}"
DB_USER="${DB_USER:-irvis_user}"
DB_PASSWORD="${DB_PASSWORD:-password}"

SEED_ADMIN_USER="${SEED_ADMIN_USER:-admin}"
SEED_ADMIN_EMAIL="${SEED_ADMIN_EMAIL:-admin@irvis.local}"
SEED_ADMIN_PASSWORD="${SEED_ADMIN_PASSWORD:-admin123}"

log() { echo "[entrypoint] $*"; }

# ---------------------------------------------------------------------------
# 1. MySQL: initialize data dir (first run only), start daemon, wait for it.
# ---------------------------------------------------------------------------
if [ ! -d /var/lib/mysql/mysql ]; then
    log "Initializing MySQL data directory..."
    mysqld --initialize-insecure --user=mysql --datadir=/var/lib/mysql
fi

log "Starting mysqld..."
mysqld_safe --user=mysql --skip-networking=0 --bind-address=127.0.0.1 &

for i in $(seq 1 60); do
    if mysqladmin ping --silent 2>/dev/null; then
        break
    fi
    sleep 1
done
if ! mysqladmin ping --silent 2>/dev/null; then
    log "ERROR: mysqld did not come up in time"
    exit 1
fi
log "MySQL is up."

# ---------------------------------------------------------------------------
# 2. Provision database, app user, and schema (idempotent).
# ---------------------------------------------------------------------------
log "Provisioning database '${DB_NAME}' and user '${DB_USER}'..."
mysql -u root <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'%' IDENTIFIED BY '${DB_PASSWORD}';
ALTER USER '${DB_USER}'@'%' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'%';
FLUSH PRIVILEGES;
SQL

# Schema is tracked in irvis-docker itself (not the cloned repo - see
# mysql-init/schema.sql for why) and was baked into the image at build time.
if [ -f "${SCHEMA_FILE}" ]; then
    log "Applying schema.sql..."
    mysql -u root < "${SCHEMA_FILE}"
else
    log "WARNING: ${SCHEMA_FILE} not found, skipping schema apply"
fi

# Seed a default admin user on first run only.
USER_COUNT=$(mysql -u root -N -B -e "SELECT COUNT(*) FROM \`${DB_NAME}\`.users;" 2>/dev/null || echo 0)
if [ "${USER_COUNT}" = "0" ]; then
    HASHED=$(printf '%s' "${SEED_ADMIN_PASSWORD}" | sha256sum | cut -d' ' -f1)
    log "Seeding default admin user '${SEED_ADMIN_USER}'..."
    mysql -u root "${DB_NAME}" <<SQL
INSERT INTO users (username, email, hashed_password, is_logged_in, is_admin)
VALUES ('${SEED_ADMIN_USER}', '${SEED_ADMIN_EMAIL}', '${HASHED}', 0, 1);
SQL
    log "Default admin login -> username: ${SEED_ADMIN_USER}  password: ${SEED_ADMIN_PASSWORD}"
fi

# ---------------------------------------------------------------------------
# 3. Clone (or refresh) the app source. Never baked into the image - always
#    fetched fresh from git so the container runs exactly what's committed.
# ---------------------------------------------------------------------------
if [ -d "${SRC_DIR}/.git" ]; then
    log "Refreshing existing checkout of ${REPO_REF}..."
    git -C "${SRC_DIR}" fetch --depth 1 origin "${REPO_REF}"
    git -C "${SRC_DIR}" reset --hard FETCH_HEAD
else
    log "Cloning ${REPO_URL} (${REPO_REF}) into ${SRC_DIR}..."
    rm -rf "${SRC_DIR}"
    git clone --depth 1 --branch "${REPO_REF}" "${REPO_URL}" "${SRC_DIR}"
fi

# ---------------------------------------------------------------------------
# 4. Compile the app.
# ---------------------------------------------------------------------------
log "Building irvis-go..."
(cd "${SRC_DIR}" && go build -o /opt/irvis-src/irvis-go ./cmd/server)
log "Build complete."

# ---------------------------------------------------------------------------
# 5. Configure networking for the chosen mode, then hand off to the app.
# ---------------------------------------------------------------------------
export DB_HOST=127.0.0.1
export DB_PORT=3306
export DB_NAME DB_USER DB_PASSWORD
export SERVER_PROTOCOL=http
export GITHUB_TOKEN="${GITHUB_TOKEN:-}"

if [ "${MODE}" = "web" ]; then
    log "Mode=web: nginx will listen on ${CONTAINER_PORT} and proxy to app on 127.0.0.1:${APP_INTERNAL_PORT}"
    export PORT="${APP_INTERNAL_PORT}"

    sed -e "s/__LISTEN_PORT__/${CONTAINER_PORT}/g" \
        -e "s/__APP_PORT__/${APP_INTERNAL_PORT}/g" \
        /etc/nginx/templates/irvis.conf.template > /etc/nginx/sites-available/irvis.conf
    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/irvis.conf /etc/nginx/sites-enabled/irvis.conf

    log "Starting nginx..."
    nginx
else
    log "Mode=local: app will listen directly on 0.0.0.0:${CONTAINER_PORT}"
    export PORT="${CONTAINER_PORT}"
fi

log "Starting irvis-go..."
cd "${SRC_DIR}"
exec ./irvis-go
